from tf2gan.loss import *
